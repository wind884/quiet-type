# 轻打 iPad 版 / Quiet Type for iPad

[中文](#中文) · [English](#english)

[打开 iPad 版 / Open the iPad edition](https://quiet-type-ipad.windgrayson.chatgpt.site) · [桌面版 / Desktop downloads](https://github.com/wind884/quiet-type/releases/latest)

## 中文

一个可以添加到 iPad 主屏幕的打字练习工具，不需要苹果开发者账号

在 Safari 打开页面，点共享按钮，选择「添加到主屏幕」；如果出现「打开为网页 App」，保持开启，再点添加

添加后从主屏幕打开一次，等底部显示「可离线使用」，之后就可以断网练习

保留桌面版的 201 组短长练习、中英界面切换、日常文章、英语考试范文、程序员练习、计时测试、个人文本和五种趣味挑战

点白色区域打开屏幕键盘，也支持外接键盘和系统输入法，中文候选字确认后才会计分；代码练习提供「缩进」按钮，屏幕键盘也能输入缩进

横屏保留文章列表，竖屏从「选文章」打开列表，字号可以自行调整

文章、成绩和错词保存在当前设备中，可以在「成绩」里导出或恢复 JSON 备份，清理 Safari 数据或更换设备前建议先备份

普通练习离开输入区时暂停，计时测试和影子赛跑继续计时

### 本地运行

需要 Node.js，项目根目录运行：

```sh
npm run build
npm test
npm start
```

打开终端显示的本地地址，发布时将 `dist/` 放到支持 HTTPS 的静态网站即可，首次离线准备需要联网

## English

A typing practice app you can add to your iPad Home Screen without an Apple developer account

Open the page in Safari, tap Share, then Add to Home Screen. If Open as Web App appears, leave it enabled and tap Add.

After adding it, open the app from your Home Screen while online and wait for Ready offline at the bottom. You can then practice without an internet connection.

The iPad edition keeps the desktop app's 201 short and long lesson pairs, Chinese/English interface, daily passages, exam writing, code practice, timed tests, personal texts, and five challenges.

Tap the white area to open the onscreen keyboard, or use an external keyboard and your system input method. Chinese composition is scored only after confirmation. Code practice has a Tab button for indentation with the onscreen keyboard.

The library stays beside the text in landscape. In portrait, use Choose text to open it. Text size is adjustable.

Texts, results, and mistake lists stay on this device. Export or restore a JSON backup in History before changing devices or clearing Safari data.

Ordinary practice pauses when the input loses focus. Timed tests and ghost races keep running.

### Run locally

With Node.js installed, run these commands from the project root:

```sh
npm run build
npm test
npm start
```

Open the local URL printed in the terminal. For hosting, serve `dist/` from an HTTPS static host. Initial offline setup needs an internet connection.
