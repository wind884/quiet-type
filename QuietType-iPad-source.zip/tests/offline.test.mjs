import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
const worker = await readFile(new URL('../src/sw.js', import.meta.url), 'utf8').catch(() => '');
function environment(failInstall = false, redirected = false) {
  assert.ok(worker, 'Offline worker is not implemented');
  const handlers = {}, deleted = [], stored = [], scope = 'https://example.test/ipad/';
  const cache = { addAll: async urls => { if (failInstall) throw new Error('network'); stored.push(...urls); }, match: async request => {
    const url = typeof request === 'string' ? request : request.url;
    if (url === scope || url.endsWith('index.html')) {
      const response = new Response('offline typing app', { headers: { 'Content-Type': 'text/html' } });
      if (redirected) Object.defineProperty(response, 'redirected', { value: true });
      return response;
    }
    return undefined;
  } };
  const context = { URL, Promise, Response, fetch: async () => { throw new Error('offline'); }, caches: { open: async () => cache, keys: async () => ['quiet-type-ipad-old', 'unrelated-app'], delete: async key => deleted.push(key) }, self: { location: new URL(scope + 'sw.js'), registration: { scope }, clients: { claim: async () => {} }, addEventListener: (type, fn) => handlers[type] = fn } };
  vm.runInNewContext(worker.replaceAll('__CACHE_ID__', 'test-cache').replace('__PRECACHE__', JSON.stringify(['./', './index.html', './app.js', './core.js', './app.css', './lessons.json', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png'])), context);
  return { handlers, deleted, stored };
}
test('offline install atomically caches the app and its lesson catalogue', async () => {
  const { handlers, stored } = environment(); let pending;
  handlers.install({ waitUntil: p => pending = p }); await pending;
  assert.ok(stored.some(x => x.endsWith('/lessons.json'))); assert.ok(stored.some(x => x.endsWith('/core.js')));
});

test('cached HTML from a canonical redirect is safe for a manual navigation request', async () => {
  const { handlers } = environment(false, true); let pending;
  handlers.fetch({ request: { method: 'GET', mode: 'navigate', redirect: 'manual', url: 'https://example.test/ipad/' }, respondWith: p => pending = p });
  const response = await pending;
  assert.equal(response.redirected, false, 'Browsers reject redirected cached responses for navigation');
  assert.equal(response.headers.get('Content-Type'), 'text/html');
  assert.equal(await response.text(), 'offline typing app');
});
test('failed first download does not report a completed offline installation', async () => {
  const { handlers } = environment(true); let pending;
  handlers.install({ waitUntil: p => pending = p }); await assert.rejects(pending, /network/);
});
test('offline navigation works inside a subdirectory without deleting another app cache', async () => {
  const { handlers, deleted } = environment(); let pending;
  handlers.activate({ waitUntil: p => pending = p }); await pending;
  assert.deepEqual(deleted, ['quiet-type-ipad-old']);
  handlers.fetch({ request: { method: 'GET', mode: 'navigate', url: 'https://example.test/ipad/' }, respondWith: p => pending = p });
  assert.equal(await (await pending).text(), 'offline typing app');
  let intercepted = false;
  handlers.fetch({ request: { method: 'GET', url: 'https://other.test/private' }, respondWith: () => intercepted = true });
  assert.equal(intercepted, false);
});
