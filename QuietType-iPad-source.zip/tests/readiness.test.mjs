import test from 'node:test';
import assert from 'node:assert/strict';
const { offlineReady } = await import('../src/offline.js').catch(() => ({}));

class Worker extends EventTarget {
  constructor(state) { super(); this.state = state; }
  change(state) { this.state = state; this.dispatchEvent(new Event('statechange')); }
}
function registration(worker, active = null) { return Object.assign(new EventTarget(), { installing: worker, active, waiting: null }); }

test('first installation is ready only after activation', async () => {
  assert.equal(typeof offlineReady, 'function');
  const worker = new Worker('installing'); let ready = false;
  const result = offlineReady(registration(worker)).then(() => { ready = true; });
  worker.change('installed'); await Promise.resolve(); assert.equal(ready, false);
  worker.change('activated'); await result; assert.equal(ready, true);
});
test('failed precaching rejects instead of waiting for a ready promise that never settles', async () => {
  assert.equal(typeof offlineReady, 'function');
  const worker = new Worker('installing');
  const result = offlineReady(registration(worker)); worker.change('redundant');
  await assert.rejects(result, /installation/);
});
test('an already active offline copy remains ready while an update downloads', async () => {
  assert.equal(typeof offlineReady, 'function');
  await offlineReady(registration(new Worker('installing'), new Worker('activated')));
});
test('an installation that stops producing events has a bounded failure', async () => {
  assert.equal(typeof offlineReady, 'function');
  await assert.rejects(offlineReady(registration(null), { timeoutMs: 5 }), /timeout/);
});
