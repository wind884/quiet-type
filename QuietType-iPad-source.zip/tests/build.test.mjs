import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
const root = new URL('../dist/', import.meta.url);
test('the installable app manifest and every referenced offline asset ship together', async () => {
  const manifestText = await readFile(new URL('manifest.webmanifest', root), 'utf8').catch(() => '');
  assert.ok(manifestText, 'The installable app has not been built');
  const manifest = JSON.parse(manifestText);
  assert.equal(manifest.display, 'standalone'); assert.equal(manifest.start_url, './'); assert.equal(manifest.scope, './');
  const html = await readFile(new URL('index.html', root), 'utf8');
  const worker = await readFile(new URL('sw.js', root), 'utf8');
  const cached = JSON.parse(worker.match(/const FILES = (\[[^\]]+\])/)[1]);
  const required = [...html.matchAll(/(?:src|href)="(\.\/[^"#]+)"/g)].map(x => x[1]);
  const scripts = required.filter(x => x.endsWith('.js'));
  for (let i = 0; i < scripts.length; i++) {
    const script = await readFile(new URL(scripts[i], root), 'utf8');
    for (const match of script.matchAll(/from\s+['"](\.\/[^'"]+)['"]/g)) if (!scripts.includes(match[1])) scripts.push(match[1]);
  }
  for (const name of [...required, ...scripts, './lessons.json', ...manifest.icons.map(x => x.src)]) {
    assert.ok(cached.includes(name), `Offline cache misses ${name}`); assert.ok((await stat(new URL(name, root))).size > 0);
  }
  for (const name of cached) assert.ok(name.startsWith('./') && !name.includes('..'), 'Cache must stay inside the app');
  assert.equal(JSON.parse(await readFile(new URL('lessons.json', root), 'utf8')).length, 201);
  for (const icon of manifest.icons) { const bytes = await readFile(new URL(icon.src, root)); const expected = Number(icon.sizes.split('x')[0]); assert.equal(bytes.readUInt32BE(16), expected); assert.equal(bytes.readUInt32BE(20), expected); }
});
