import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const core = await import('../src/core.js').catch(error => {
  if (error.code === 'ERR_MODULE_NOT_FOUND') return {};
  throw error;
});
const lessons = JSON.parse(await readFile(new URL('../content/lessons.json', import.meta.url), 'utf8'));
function session(text, options = {}, now) {
  assert.equal(typeof core.Session, 'function', 'Typing session is not implemented');
  return new core.Session(text, options, now);
}

test('resaving an unfinished round refreshes elapsed time without counting mistakes twice', () => {
  assert.equal(typeof core.persistRound, 'function');
  let now = 0;
  const s = session('abcdef', {}, () => now), store = new core.Store({ getItem: () => null, setItem() {} });
  const round = { id: 'elapsed', item: { Title: 'Text', Language: 'English' }, page: 'daily', long: false, session: s, peeksUsed: 0, recordedMistakes: 0 };
  s.setActive(true); s.commit('ax'); now = 5; core.persistRound(round, store, true);
  assert.equal(store.data.results[0].seconds, 5); assert.equal(store.data.results[0].cpm, 12); assert.equal(store.data.mistakes[0].count, 1);
  now = 25; core.persistRound(round, store, true);
  assert.equal(store.data.results.length, 1); assert.equal(store.data.results[0].seconds, 25);
  assert.equal(store.data.results[0].cpm, 2.4); assert.equal(store.data.mistakes[0].count, 1);
  assert.equal(JSON.parse(store.export()).results[0].seconds, 25);
});
test('normalization preserves punctuation and code indentation', () => {
  assert.equal(core.normalizeText?.(' \uFEFFHello.\t 你好。\r\nNext\u200B '), 'Hello. 你好。 Next');
  assert.equal(core.normalizeText('\nif (ok) {\r\n\trun();\r}\n', true), 'if (ok) {\n    run();\n}');
});
test('blank, control, right-to-left and oversized text is rejected', () => {
  assert.equal(typeof core.normalizeText, 'function');
  for (const text of ['', ' \n', 'a\0b', 'مرحبا', '\uFFFD', '中'.repeat(40001)]) assert.throws(() => core.normalizeText(text));
});
test('a committed Unicode batch and backspace use graphemes', () => {
  const s = session('á👩‍💻你好，世界🇨🇳👍🏽');
  s.setActive(true); s.commit('a\u0301👩‍💻你好');
  assert.equal(s.position, 4); assert.equal(s.attempts, 4);
  s.backspace(); assert.equal(s.typed, 'á👩‍💻你');
  s.commit('好，世界🇨🇳👍🏽'); assert.equal(s.reason, 'completed');
});
test('correction preserves cumulative accuracy and captured wrong words', () => {
  const s = session('hello world'); s.commit('hexx'); s.backspace(true); s.commit('hello ');
  assert.equal(s.typed, 'hello '); assert.equal(s.accuracy, 80); assert.equal(s.errorCount, 0);
  assert.deepEqual(s.missedTokens, ['hello', 'hello']);
});
test('ordinary practice pauses while the input is unfocused', () => {
  let now = 0; const s = session('abcdef', {}, () => now);
  s.setActive(true); s.commit('a'); now = 5; s.setActive(false); now = 20;
  assert.equal(s.elapsedSeconds, 5); s.setActive(true); now = 22; assert.equal(s.elapsedSeconds, 7);
});
test('timed tests keep wall time in the background and freeze at their deadline', () => {
  let now = 10; const s = session('abcdef', { timeLimit: 30, background: true }, () => now);
  s.setActive(true); s.commit('a'); now = 15; s.setActive(false); now = 42; s.tick();
  assert.equal(s.reason, 'timeUp'); assert.equal(s.elapsedSeconds, 30); assert.equal(s.cpm, 2);
  assert.equal(s.commit('b'), false); assert.equal(s.backspace(), false);
});
test('one life and mistake rematch stop a batch at the mistake limit', () => {
  const one = session('中国文字', { game: 2, mistakeLimit: 1 }); one.commit('中错后续');
  assert.equal(one.position, 2); assert.equal(one.reason, 'lost');
  const revenge = session('abcdefghi', { game: 5, mistakeLimit: 3 }); revenge.commit('xxxmore');
  assert.equal(revenge.position, 3); assert.equal(revenge.totalMistakes, 3);
});
test('combo rewards cannot be farmed by deleting and retyping', () => {
  const s = session('abcdefghijklmnopqrstuvwxyz', { game: 1 }); s.commit('abcdefghijk');
  const score = s.score; s.backspace(); s.commit('k'); assert.equal(s.score, score);
  const bad = session('abcdefghij', { game: 1 }); bad.commit('xxcdefghij'); assert.equal(bad.reason, 'lost');
});
test('memory, race and rematch require a correct final copy', () => {
  for (const game of [3, 4, 5]) { const s = session('abc', { game }); s.commit('xbc'); assert.equal(s.reason, 'lost'); }
});
test('only free practice completion can be reopened with backspace', () => {
  const s = session('abc'); s.commit('abc'); assert.equal(s.backspace(), true); assert.equal(s.reason, 'none');
  const game = session('abc', { game: 1 }); game.commit('abc'); assert.equal(game.backspace(), false);
});
test('IME drafts do not score and duplicate final input is ignored', () => {
  assert.equal(typeof core.InputBuffer, 'function');
  const s = session('中文abc'); const b = new core.InputBuffer(s); const epoch = b.epoch;
  b.begin(epoch); b.accept('zhong', { epoch, composing: true });
  assert.equal(s.attempts, 0); b.end('中文', epoch); b.accept('中文', { epoch }); b.end('中文', epoch);
  assert.equal(s.typed, '中文'); assert.equal(s.attempts, 2);
});
test('old-round composition events cannot leak into a new round', () => {
  assert.equal(typeof core.InputBuffer, 'function');
  const old = session('中文'); const next = session('next'); const b = new core.InputBuffer(old); const epoch = b.epoch;
  b.begin(epoch); b.reset(next); b.end('中文', epoch); b.accept('中文', { epoch });
  assert.equal(old.attempts, 0); assert.equal(next.attempts, 0);
});
test('native deletion and replacement count new attempts without resetting accuracy', () => {
  assert.equal(typeof core.InputBuffer, 'function');
  const s = session('hello'); const b = new core.InputBuffer(s);
  b.accept('hex'); b.accept('he'); b.accept('hello'); assert.equal(s.typed, 'hello'); assert.equal(s.attempts, 6);
  assert.ok(s.accuracy < 100);
});
test('all 201 lessons keep short and long passages and bilingual challenges', () => {
  assert.equal(typeof core.queryLessons, 'function'); assert.equal(lessons.length, 201);
  for (const item of lessons) { assert.ok(item.Id && item.ShortText && item.LongText && item.TitleEn); core.normalizeText(item.LongText, item.IsCode); }
  assert.equal(core.queryLessons(lessons, 'daily', 'en', '', '').length, 70);
  assert.equal(core.queryLessons(lessons, 'daily', 'zh', '', '').length, 70);
  for (const lang of ['en', 'zh']) assert.equal(core.queryLessons(lessons, 'games', lang, '', '').length, 20);
  assert.equal(core.queryLessons(lessons, 'code', 'JavaScript', '', '').length, 1);
  assert.ok(core.queryLessons(lessons, 'daily', 'zh', '', 'rain').length > 0);
});
test('custom text short excerpts do not split emoji or erase punctuation', () => {
  assert.equal(typeof core.shortenText, 'function');
  assert.equal(core.shortenText('你好世界👩‍💻', 3), '你好世');
  assert.equal(core.shortenText('one useful word and more', 12), 'one useful');
});
test('timed targets last for the test and revenge uses the correct language', () => {
  assert.equal(typeof core.roundTarget, 'function');
  const en = lessons.find(x => x.Language === '英语' && x.Game === 5);
  const result = core.roundTarget(en, false, 'games', [{ text: 'hello', count: 2 }, { text: '中文', count: 3 }]);
  assert.equal(result.target, 'hello'); assert.deepEqual(result.used, ['hello']);
  const timed = core.roundTarget(lessons[0], false, 'test', []);
  assert.ok(core.units(timed.target).length >= 4000 && core.units(timed.target).length <= 35000);
});
test('failed local storage writes retain new text in memory', () => {
  assert.equal(typeof core.Store, 'function');
  const storage = { getItem: () => null, setItem() { throw new Error('QuotaExceededError'); } };
  const store = new core.Store(storage); store.saveText({ id: 'one', title: 'Notes', language: 'French', text: 'Bonjour.' });
  assert.equal(store.data.texts[0].text, 'Bonjour.'); assert.ok(store.error);
});
test('corrupt local data is kept and backup import is validated atomically', () => {
  assert.equal(typeof core.Store, 'function');
  const map = new Map([['quiet-type-ipad', '{broken']]);
  const storage = { getItem: k => map.get(k) ?? null, setItem: (k, v) => map.set(k, v) };
  const store = new core.Store(storage); assert.equal(map.get('quiet-type-ipad'), '{broken');
  store.saveText({ id: 'one', title: 'Notes', language: 'English', text: 'Safe text' });
  assert.ok([...map.keys()].some(x => x.startsWith('quiet-type-ipad-backup-')));
  const before = store.export(); assert.throws(() => store.import('{"texts":[{"title":"Bad"}]}'));
  assert.equal(store.export(), before);
});
test('record replacement does not duplicate scores or mistakes', () => {
  assert.equal(typeof core.Store, 'function');
  const store = new core.Store({ getItem: () => null, setItem() {} });
  const record = { id: 'same', title: 'One', cpm: 40, accuracy: 90 };
  store.record(record, ['word']); store.record({ ...record, cpm: 50 }, []);
  assert.equal(store.data.results.length, 1); assert.equal(store.data.results[0].cpm, 50); assert.equal(store.data.mistakes[0].count, 1);
});
test('language aliases also work for custom text with spaces or different casing', () => {
  assert.equal(core.languageKey({ Language: ' english ' }), 'en');
  assert.equal(core.languageKey({ Language: 'FRANÇAIS' }), 'fr');
});
test('scores use the completed round snapshot after the user changes filters or length', () => {
  assert.equal(typeof core.scoreRecord, 'function');
  const s = session('abc'); s.commit('abc');
  const round = { id: 'round', item: lessons[0], page: 'daily', long: false, session: s, peeksUsed: 0 };
  const result = core.scoreRecord(round, '2026-10-24T10:00:00Z');
  assert.equal(result.page, 'daily'); assert.equal(result.long, false); assert.equal(result.title, lessons[0].Title);
  assert.equal(result.result, 'completed'); assert.equal(result.accuracy, 100);
});
