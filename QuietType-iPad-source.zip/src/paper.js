import { InputBuffer, cellSpan, isWord } from './core.js';

export class Paper {
  constructor(element, reference, draft, changed) {
    this.element = element; this.reference = reference; this.draft = draft; this.changed = changed;
    this.cells = []; this.lastPaint = []; this.allowed = true; this.label = '打字输入区';
    element.addEventListener('pointerdown', () => this.focus());
    reference.addEventListener('scroll', () => this.positionInput(), { passive: true });
    new ResizeObserver(() => { this.measure(); this.positionInput(); }).observe(element);
  }
  load(session) {
    if (this.buffer) this.buffer.reset(session); else this.buffer = new InputBuffer(session);
    this.input?.remove(); this.session = session; this.lastPaint = []; this.cells = [];
    const fragment = document.createDocumentFragment(); let word;
    session.targetUnits.forEach((unit, index) => {
      if (isWord(unit)) {
        if (!word) { word = document.createElement('span'); word.className = 'word'; fragment.append(word); }
      } else word = null;
      const cell = document.createElement('span'); cell.className = `char${cellSpan(unit) === 2 ? ' wide' : ''}${unit === '\n' ? ' newline' : ''}`;
      cell.textContent = unit === '\n' ? '↵' : unit; cell.dataset.index = String(index);
      (word || fragment).append(cell); this.cells.push(cell);
      if (unit === '\n') fragment.append(document.createElement('br'));
    });
    const end = document.createElement('span'); end.className = 'char'; end.textContent = '\u200b'; fragment.append(end); this.cells.push(end);
    this.reference.replaceChildren(fragment); this.reference.scrollTop = 0;
    const input = document.createElement('textarea'); this.input = input;
    input.className = 'capture'; input.rows = 1; input.wrap = 'off'; input.spellcheck = false;
    input.setAttribute('autocorrect', 'off'); input.setAttribute('autocapitalize', 'off'); input.setAttribute('autocomplete', 'off');
    input.setAttribute('writingsuggestions', 'false'); input.setAttribute('aria-label', this.label); input.setAttribute('inputmode', 'text');
    input.setAttribute('enterkeyhint', 'enter'); this.element.append(input);
    const epoch = this.buffer.epoch, live = () => this.input === input && this.buffer.epoch === epoch;
    const sync = () => { if (!live()) return; input.value = session.typed; input.setSelectionRange(input.value.length, input.value.length); this.paint(); this.changed(); };
    input.addEventListener('compositionstart', () => { if (live()) this.buffer.begin(epoch); });
    input.addEventListener('compositionupdate', event => { if (live()) { this.buffer.update(event.data, epoch); this.paintDraft(); } });
    input.addEventListener('compositionend', () => queueMicrotask(() => {
      if (!live()) return; this.buffer.end(input.value, epoch); sync();
    }));
    input.addEventListener('input', event => {
      if (!live()) return;
      if (!this.allowed) { input.value = session.typed; return; }
      if (event.isComposing || this.buffer.composing) { if (event.data) this.buffer.update(event.data, epoch); this.paintDraft(); return; }
      this.buffer.accept(input.value, { epoch }); sync();
    });
    input.addEventListener('beforeinput', event => { if (!this.allowed || /insertFrom(Paste|Drop)/.test(event.inputType)) event.preventDefault(); });
    input.addEventListener('paste', event => event.preventDefault());
    input.addEventListener('drop', event => event.preventDefault());
    input.addEventListener('focus', () => { if (live()) { this.element.classList.add('focused'); session.setActive(!document.hidden && this.allowed); this.changed(); } });
    input.addEventListener('blur', () => { if (live()) { this.element.classList.remove('focused'); session.setActive(false); this.changed(); } });
    input.addEventListener('select', () => { if (live() && !this.buffer.composing && (input.selectionStart !== input.value.length || input.selectionEnd !== input.value.length)) input.setSelectionRange(input.value.length, input.value.length); });
    input.addEventListener('keydown', event => {
      if (!live() || event.isComposing || this.buffer.composing) return;
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) event.preventDefault();
      if (event.key === 'Backspace' && (event.metaKey || event.altKey || event.ctrlKey)) { event.preventDefault(); if (this.allowed && session.backspace(true)) sync(); }
      if (event.key === 'Tab' && session.options.code) { event.preventDefault(); this.indent(); }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'v') event.preventDefault();
    });
    this.measure(); this.paint();
  }
  clear() { this.input?.remove(); this.input = null; this.buffer?.reset(null); this.session = null; this.reference.replaceChildren(); this.draft.textContent = ''; }
  measure() {
    const computed = getComputedStyle(this.reference), canvas = document.createElement('canvas');
    const context = canvas.getContext('2d'); if (!context) return;
    context.font = `${computed.fontSize} ${computed.fontFamily}`;
    this.element.style.setProperty('--cell-width', `${Math.ceil(context.measureText('M').width * 10) / 10}px`);
  }
  focus() { if (this.input && this.allowed) this.input.focus({ preventScroll: true }); }
  setAllowed(value) { this.allowed = value; if (this.input) this.input.readOnly = !value; this.session?.setActive(value && document.activeElement === this.input && !document.hidden); }
  setLabel(value) { this.label = value; this.input?.setAttribute('aria-label', value); }
  setMask(value) { this.reference.classList.toggle('mask', value); }
  visibility() { this.session?.setActive(this.allowed && !document.hidden && document.activeElement === this.input); }
  paint() {
    const session = this.session; if (!session) return;
    let prefix = 0; while (prefix < this.lastPaint.length && prefix < session.position && this.lastPaint[prefix] === session.inputUnits[prefix]) prefix++;
    this.reference.querySelector('.cursor')?.classList.remove('cursor');
    for (let index = prefix; index < Math.max(session.position, this.lastPaint.length); index++) {
      const cell = this.cells[index]; if (!cell) continue;
      const typed = index < session.position, unit = typed ? session.inputUnits[index] : session.targetUnits[index];
      cell.textContent = unit === '\n' ? '↵' : unit; cell.classList.toggle('typed', typed); cell.classList.toggle('wrong', typed && unit !== session.targetUnits[index]);
    }
    this.lastPaint = [...session.inputUnits]; this.cells[session.position]?.classList.add('cursor');
    if (document.activeElement === this.input) this.cells[session.position]?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    this.positionInput(); this.paintDraft();
  }
  positionInput() {
    if (!this.input || !this.session || !this.cells[this.session.position]) return;
    const box = this.element.getBoundingClientRect(), caret = this.cells[this.session.position].getBoundingClientRect();
    const x = Math.max(3, Math.min(this.element.clientWidth - 27, caret.left - box.left));
    const y = Math.max(3, Math.min(this.element.clientHeight - 30, caret.top - box.top));
    this.input.style.left = `${x}px`; this.input.style.top = `${y}px`; this.draft.style.left = `${x}px`; this.draft.style.top = `${y + 3}px`;
  }
  paintDraft() { this.draft.textContent = this.buffer?.composing ? this.buffer.draft : ''; }
  indent() {
    if (!this.allowed || !this.session?.options.code || this.buffer.composing) return;
    let count = 0; while (count < 4 && this.session.targetUnits[this.session.position + count] === ' ') count++;
    this.session.commit(' '.repeat(Math.max(1, count))); this.input.value = this.session.typed;
    this.input.setSelectionRange(this.input.value.length, this.input.value.length); this.paint(); this.changed(); this.focus();
  }
}
