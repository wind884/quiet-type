export function offlineReady(registration, { timeoutMs = 45000 } = {}) {
  return new Promise((resolve, reject) => {
    const watched = new Set();
    let settled = false;
    const timer = setTimeout(() => finish(new Error('Offline installation timeout')), timeoutMs);
    function finish(error) {
      if (settled) return;
      settled = true; clearTimeout(timer);
      registration.removeEventListener('updatefound', inspect);
      for (const worker of watched) worker.removeEventListener('statechange', inspect);
      if (error) reject(error); else resolve();
    }
    function inspect() {
      const workers = [registration.active, registration.installing, registration.waiting].filter(Boolean);
      if (workers.some(worker => worker.state === 'activated')) { finish(); return; }
      for (const worker of workers) {
        if (!watched.has(worker)) { watched.add(worker); worker.addEventListener('statechange', inspect); }
      }
      if ([...watched].some(worker => worker.state === 'activated')) finish();
      else if ([...watched].some(worker => worker.state === 'redundant')) finish(new Error('Offline installation failed'));
    }
    registration.addEventListener('updatefound', inspect);
    inspect();
  });
}
