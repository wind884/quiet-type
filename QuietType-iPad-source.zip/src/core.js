const segmenter = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
export const units = text => [...segmenter.segment(String(text).normalize('NFC'))].map(x => x.segment);
const rtl = /[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefc\u200f\u202b\u202e\u2067]|[\u{10800}-\u{10fff}\u{1e800}-\u{1eeff}]/u;
export function normalizeText(text, code = false) {
  let value = String(text).normalize('NFC').replace(/\r\n?/g, '\n').replace(/[\uFEFF\u200B]/g, '');
  if (rtl.test(value)) throw new Error('rtl');
  if (/[\uFFFD\uFFFE\uFFFF]/u.test(value)) throw new Error('invalid');
  if (code) value = value.replace(/\t/g, '    ').replace(/^\n+|\n+$/g, '');
  else value = value.replace(/\s+/gu, ' ').trim();
  value = value.replace(/\u00a0/g, ' ');
  if (/[^\S\n ]/u.test(value) || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]/u.test(value)) throw new Error('control');
  if (!value.trim()) throw new Error('blank');
  if (units(value).length > 40000) throw new Error('tooLong');
  return value;
}
export function cellSpan(unit) {
  const c = unit.codePointAt(0);
  return c >= 0x1100 && (c <= 0x115f || c === 0x2329 || c === 0x232a || c >= 0x2e80 && c <= 0xa4cf || c >= 0xac00 && c <= 0xd7a3 || c >= 0xf900 && c <= 0xfaff || c >= 0xfe10 && c <= 0xfe6f || c >= 0xff00 && c <= 0xff60 || c >= 0x1f000) ? 2 : 1;
}
export const isWord = unit => !!unit && cellSpan(unit) === 1 && /[\p{L}\p{N}_'-]/u.test(unit);
export function shortenText(text, maximum = 160, code = false) {
  const a = units(normalizeText(text, code)); let end = Math.max(1, maximum);
  if (a.length <= end) return a.join('');
  let boundary = end;
  if (code) { while (boundary > end / 2 && a[boundary - 1] !== '\n') boundary--; if (boundary > end / 2) end = boundary; }
  else { while (boundary > end * .75 && isWord(a[boundary])) boundary--; if (boundary > end * .75) end = boundary; }
  return a.slice(0, end).join('').trimEnd();
}
function mistakeToken(a, index) {
  let at = Math.min(index, a.length - 1); if (a[at] === ' ' || a[at] === '\n') at = Math.max(0, at - 1);
  let start = at, end = at + 1;
  if (isWord(a[at])) { while (start > 0 && isWord(a[start - 1])) start--; while (end < a.length && isWord(a[end])) end++; }
  else if (cellSpan(a[at]) > 1) { start = Math.max(0, at - 1); end = Math.min(a.length, at + 2); }
  return a.slice(start, Math.min(end, start + 32)).join('').trim();
}
export class Session {
  constructor(target, options = {}, now = () => Date.now() / 1000) {
    this.options = { game: 0, timeLimit: 0, mistakeLimit: 0, background: false, code: false, ...options };
    this.target = normalizeText(target, this.options.code); this.targetUnits = units(this.target); this.inputUnits = [];
    this.attempts = 0; this.totalMistakes = 0; this.correctAttempts = 0; this.combo = 0; this.bestCombo = 0; this.score = 0;
    this.missedTokens = []; this.reason = 'none'; this.rewarded = new Set(); this.now = now;
    this.elapsed = 0; this.last = 0; this.active = false; this.hasStarted = false; this.isRunning = false;
  }
  get typed() { return this.inputUnits.join(''); }
  get position() { return this.inputUnits.length; }
  get correctCount() { return this.inputUnits.reduce((sum, x, i) => sum + (x === this.targetUnits[i] ? 1 : 0), 0); }
  get errorCount() { return this.position - this.correctCount; }
  get accuracy() { return this.attempts ? this.correctAttempts * 100 / this.attempts : 100; }
  get finished() { return this.reason !== 'none'; }
  get elapsedSeconds() { const value = this.elapsed + (this.isRunning ? Math.max(0, this.now() - this.last) : 0); return this.options.timeLimit > 0 ? Math.min(value, this.options.timeLimit) : value; }
  get cpm() { return this.correctCount * 60 / Math.max(1, this.elapsedSeconds); }
  clock(run) { if (this.isRunning === run) return; if (this.isRunning) this.elapsed += Math.max(0, this.now() - this.last); this.isRunning = run; if (run) this.last = this.now(); }
  finish(reason) { const elapsed = this.elapsedSeconds; this.clock(false); this.elapsed = elapsed; this.reason = reason; }
  tick() { if (!this.finished && this.hasStarted && this.options.timeLimit > 0 && this.elapsedSeconds >= this.options.timeLimit) this.finish(this.options.game === 4 ? 'lost' : 'timeUp'); }
  setActive(active) { this.tick(); this.active = active; this.clock(!this.finished && this.hasStarted && (active || this.options.background)); }
  commit(text) {
    this.tick(); if (this.finished || !text) return false; let changed = false;
    for (const unit of units(text.replace(/\r\n?/g, '\n'))) {
      if (this.finished) break;
      if (unit === '\n' && !this.options.code || unit !== '\n' && /\p{Cc}/u.test(unit)) continue;
      if (!this.hasStarted) { this.hasStarted = true; this.clock(this.active || this.options.background); }
      const at = this.position, correct = unit === this.targetUnits[at];
      this.inputUnits.push(unit); this.attempts++; changed = true;
      if (correct) {
        this.correctAttempts++;
        if (!this.rewarded.has(at)) { this.rewarded.add(at); this.combo++; this.bestCombo = Math.max(this.bestCombo, this.combo); this.score += this.options.game === 1 ? Math.min(5, 1 + Math.floor(this.combo / 10)) : 1; }
      } else {
        this.totalMistakes++; this.combo = 0; const token = mistakeToken(this.targetUnits, at); if (token) this.missedTokens.push(token);
      }
      if (!correct && this.options.mistakeLimit > 0 && this.totalMistakes >= this.options.mistakeLimit) this.finish('lost');
      else if (this.position >= this.targetUnits.length) this.finish([3, 4, 5].includes(this.options.game) && this.errorCount > 0 || this.options.game === 1 && this.accuracy < 90 ? 'lost' : 'completed');
    }
    return changed;
  }
  backspace(word = false) {
    this.tick(); if (!this.position) return false;
    if (this.finished) { if (this.reason !== 'completed' || this.options.game || this.options.timeLimit > 0) return false; this.reason = 'none'; }
    let end = this.position - 1;
    if (word) { end = this.position; while (end > 0 && !this.inputUnits[end - 1].trim()) end--; if (end > 0 && isWord(this.inputUnits[end - 1])) { while (end > 0 && isWord(this.inputUnits[end - 1])) end--; } else if (end > 0) end--; }
    this.inputUnits.length = end; this.clock(this.active || this.options.background); return true;
  }
}
export class InputBuffer {
  constructor(session) { this.epoch = 0; this.reset(session); }
  reset(session) { this.session = session; this.epoch++; this.composing = false; this.draft = ''; }
  begin(epoch = this.epoch) { if (epoch !== this.epoch) return; this.composing = true; this.draft = ''; }
  update(text, epoch = this.epoch) { if (epoch === this.epoch) this.draft = String(text || ''); }
  end(value, epoch = this.epoch) { if (epoch !== this.epoch) return false; this.composing = false; this.draft = ''; return this.accept(value, { epoch }); }
  accept(value, { epoch = this.epoch, composing = false } = {}) {
    if (epoch !== this.epoch) return false;
    if (this.composing || composing) return false;
    const next = units(String(value).replace(/\r\n?/g, '\n')), previous = this.session.inputUnits;
    let prefix = 0; while (prefix < next.length && prefix < previous.length && next[prefix] === previous[prefix]) prefix++;
    if (prefix === next.length && prefix === previous.length) return false;
    let changed = false;
    while (this.session.position > prefix) { if (!this.session.backspace()) return changed; changed = true; }
    return this.session.commit(next.slice(prefix).join('')) || changed;
  }
}
export function languageKey(item) {
  if (item.IsCode) return item.Language;
  const value = String(item.Language || '').trim();
  const keys = { '英语': 'en', english: 'en', en: 'en', '中文': 'zh', chinese: 'zh', zh: 'zh', '日语': 'ja', '日本語': 'ja', japanese: 'ja', '韩语': 'ko', '한국어': 'ko', korean: 'ko', '法语': 'fr', 'français': 'fr', french: 'fr', '西班牙语': 'es', 'español': 'es', spanish: 'es', '德语': 'de', deutsch: 'de', german: 'de', '俄语': 'ru', 'русский': 'ru', russian: 'ru', '混合': 'mixed', '混合文本': 'mixed', mixed: 'mixed' };
  return keys[value.toLocaleLowerCase()] || value;
}
export function examGroup(item) {
  for (const [id, group] of [['ielts-chart', 'IELTS Task 1'], ['ielts-essay', 'IELTS Task 2'], ['toefl-email', 'TOEFL Email'], ['toefl-discussion', 'TOEFL Discussion'], ['cet4', 'CET-4'], ['cet6', 'CET-6']]) if (item.Id.includes(id)) return group;
  return item.CategoryEn;
}
export function savedLesson(text) {
  return { Id: `user:${text.id}`, Title: text.title, TitleEn: text.title, Language: text.language, ShortText: shortenText(text.text), LongText: normalizeText(text.text), Section: 2, IsCode: false, Game: 0, Category: '我的文本', CategoryEn: 'My texts', Description: '本机文本库', DescriptionEn: 'Saved on this device' };
}
export function queryLessons(all, page, language = '', group = '', search = '', saved = []) {
  const sections = { daily: [0, 1, 2], exams: [3], code: [5], games: [6], test: [0, 1, 4] };
  const candidates = page === 'library' ? saved.map(savedLesson) : all.filter(x => (sections[page] || []).includes(x.Section));
  const needle = search.trim().toLocaleLowerCase();
  return candidates.filter(x => (!language || languageKey(x) === language) && (!group || String(page === 'games' ? x.Game : page === 'exams' ? examGroup(x) : x.CategoryEn) === group) && (!needle || `${x.Title} ${x.TitleEn}`.toLocaleLowerCase().includes(needle)));
}
export function tokenMatches(token, language) { const chinese = /[\u3400-\u9fff]/u.test(token), latin = /[a-z]/i.test(token); return language === 'zh' ? chinese : language === 'en' ? latin && !chinese : true; }
export function roundTarget(item, long, page, mistakes) {
  let target = long ? item.LongText : item.ShortText, used = [];
  if (item.Game === 5) {
    used = mistakes.filter(x => tokenMatches(x.text, languageKey(item))).slice(0, long ? 35 : 10).map(x => x.text);
    if (used.length) { target = used.join(' '); if (long) target = `${target} ${target} ${target}`; }
  }
  if (page === 'test') { const seed = target; while (units(target).length < (long ? 12000 : 4000)) target += ` ${seed}`; if (units(target).length > 35000) target = shortenText(target, 35000); }
  return { target: normalizeText(target, item.IsCode), used };
}
export function scoreRecord(round, when = new Date().toISOString()) {
  const s = round.session, item = round.item;
  return { id: round.id, title: item.Title, titleEn: item.TitleEn, language: item.Language, page: round.page, long: round.long, when, result: s.finished ? s.reason : 'stopped', cpm: s.cpm, accuracy: s.accuracy, seconds: s.elapsedSeconds, score: s.score * (item.Game === 3 ? Math.max(1, 3 - round.peeksUsed) : 1), bestCombo: s.bestCombo };
}
export function persistRound(round, store, stopped = false) {
  if (!round?.session.hasStarted) return false;
  const s = round.session;
  if (!s.finished && !stopped) return false;
  const record = scoreRecord(round);
  const signature = `${s.reason}:${s.attempts}:${s.position}:${record.seconds}`;
  if (round.savedSignature === signature) return false;
  store.record(record, s.missedTokens.slice(round.recordedMistakes || 0));
  round.recordedMistakes = s.missedTokens.length;
  round.savedSignature = signature;
  return true;
}
const emptyData = () => ({ texts: [], results: [], mistakes: [], locale: 'zh', fontSize: 16 });
const copy = value => JSON.parse(JSON.stringify(value));
const cleanString = (value, limit = 200) => typeof value === 'string' ? value.slice(0, limit) : '';
const bounded = (value, min, max, fallback = 0) => Number.isFinite(Number(value)) ? Math.min(max, Math.max(min, Number(value))) : fallback;
export function validateSaved(text) {
  if (!text || typeof text !== 'object') throw new Error('incomplete');
  const result = { id: cleanString(text.id, 100) || newID(), title: cleanString(text.title, 120).trim(), language: cleanString(text.language, 40).trim(), text: normalizeText(text.text ?? '') };
  if (!result.title || !result.language) throw new Error('incomplete'); return result;
}
export function newID() { return globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`; }
function repairData(raw, strict = false) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('invalid');
  const data = emptyData(); data.locale = raw.locale === 'en' ? 'en' : 'zh'; data.fontSize = bounded(raw.fontSize, 13, 21, 16);
  if (strict && !Array.isArray(raw.texts)) throw new Error('invalid');
  for (const text of (Array.isArray(raw.texts) ? raw.texts : []).slice(0, 200)) { try { const item = validateSaved(text); if (!data.texts.some(x => x.id === item.id)) data.texts.push(item); } catch (error) { if (strict) throw error; } }
  const seen = new Set();
  for (const r of (Array.isArray(raw.results) ? raw.results : []).slice(0, 300)) {
    if (!r || typeof r !== 'object') continue;
    const id = cleanString(r.id, 100); if (!id || seen.has(id)) continue; seen.add(id);
    data.results.push({ id, title: cleanString(r.title), titleEn: cleanString(r.titleEn), language: cleanString(r.language, 40), page: cleanString(r.page, 20), result: cleanString(r.result, 30), when: cleanString(r.when, 40), long: !!r.long, cpm: bounded(r.cpm, 0, 100000), accuracy: bounded(r.accuracy, 0, 100), seconds: bounded(r.seconds, 0, 864000), score: bounded(r.score, 0, 1e9), bestCombo: bounded(r.bestCombo, 0, 40000) });
  }
  for (const m of (Array.isArray(raw.mistakes) ? raw.mistakes : []).slice(0, 500)) {
    if (!m || typeof m !== 'object') continue; const text = cleanString(m.text, 100).trim();
    if (text && !data.mistakes.some(x => x.text === text)) data.mistakes.push({ text, count: Math.floor(bounded(m.count, 1, 1000000, 1)) });
  }
  return data;
}
export class Store {
  constructor(storage) {
    this.storage = storage; this.data = emptyData(); this.error = ''; this.original = ''; this.needsBackup = false;
    try { const raw = storage.getItem('quiet-type-ipad'); if (raw) { this.original = raw; this.data = repairData(JSON.parse(raw), true); } }
    catch { this.needsBackup = true; this.error = 'read'; }
  }
  save() {
    try {
      const raw = JSON.stringify(this.data); if (raw.length > 4 * 1024 * 1024) throw new Error('tooLarge');
      if (this.needsBackup && this.original) { this.storage.setItem(`quiet-type-ipad-backup-${Date.now()}`, this.original); this.needsBackup = false; }
      this.storage.setItem('quiet-type-ipad', raw); this.error = ''; return true;
    } catch { this.error = 'write'; return false; }
  }
  saveText(text) { const value = validateSaved(text); const index = this.data.texts.findIndex(x => x.id === value.id); if (index < 0) { if (this.data.texts.length >= 200) throw new Error('textLimit'); this.data.texts.unshift(value); } else this.data.texts[index] = value; return this.save(); }
  deleteText(id) { this.data.texts = this.data.texts.filter(x => x.id !== id); return this.save(); }
  record(record, missed = []) {
    this.data.results = [record, ...this.data.results.filter(x => x.id !== record.id)].slice(0, 300);
    for (const text of missed) { const item = this.data.mistakes.find(x => x.text === text); if (item) item.count = Math.min(1000000, item.count + 1); else this.data.mistakes.push({ text, count: 1 }); }
    this.data.mistakes.sort((a, b) => b.count - a.count); this.data.mistakes.length = Math.min(500, this.data.mistakes.length); return this.save();
  }
  clearMistakes(tokens) { this.data.mistakes = this.data.mistakes.filter(x => !tokens.includes(x.text)); return this.save(); }
  export() { return JSON.stringify(this.data, null, 2); }
  import(text) { if (text.length > 4 * 1024 * 1024) throw new Error('tooLarge'); const candidate = repairData(JSON.parse(text), true); this.data = copy(candidate); return this.save(); }
}
