const CACHE = 'quiet-type-ipad-__CACHE_ID__';
const SCOPE = new URL(self.registration.scope);
const FILES = __PRECACHE__.map(path => new URL(path, SCOPE).href);
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES))));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('quiet-type-ipad-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  const request = event.request, url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== SCOPE.origin || !url.pathname.startsWith(SCOPE.pathname)) return;
  event.respondWith(caches.open(CACHE).then(async cache => {
    const cached = await cache.match(request.mode === 'navigate' ? SCOPE.href : request, { ignoreSearch: true });
    if (cached?.redirected && request.mode === 'navigate') return new Response(cached.body, { status: cached.status, statusText: cached.statusText, headers: cached.headers });
    return cached || fetch(request);
  }));
});
