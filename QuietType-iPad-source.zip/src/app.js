import { Session, Store, units, languageKey, queryLessons, roundTarget, scoreRecord, persistRound, newID } from './core.js';
import { Paper } from './paper.js';
import { offlineReady } from './offline.js';

const $ = id => document.getElementById(id);
const drawerLayout = () => matchMedia('(max-width:820px), (max-width:1200px) and (orientation:portrait)').matches;
let storage; try { storage = localStorage; } catch { storage = { getItem() { throw new Error('unavailable'); }, setItem() { throw new Error('unavailable'); } }; }
const store = new Store(storage);
const pages = [['daily', '日常练习', 'Daily practice'], ['exams', '英语考试', 'Exam writing'], ['code', '程序员', 'Code'], ['games', '趣味挑战', 'Challenges'], ['test', '计时测试', 'Timed test'], ['library', '我的文本', 'My texts']];
const games = [['1', '连击闯关', 'Combo run'], ['2', '一命通关', 'One life'], ['3', '记忆闪打', 'Memory flash'], ['4', '影子赛跑', 'Ghost race'], ['5', '错字复仇', 'Mistake rematch']];
const topics = [['', '全部分类', 'All topics'], ['Everyday', '生活', 'Everyday'], ['Travel', '旅行', 'Travel'], ['Nature', '自然', 'Nature'], ['Science', '科学', 'Science'], ['Cities', '城市', 'Cities'], ['People', '人物', 'People'], ['Food', '饮食', 'Food'], ['Mystery', '微悬疑', 'Mystery']];
const languages = { en: ['英语', 'English'], zh: ['中文', 'Chinese'], ja: ['日语', 'Japanese'], ko: ['韩语', 'Korean'], fr: ['法语', 'French'], es: ['西班牙语', 'Spanish'], de: ['德语', 'German'], ru: ['俄语', 'Russian'], mixed: ['混合文本', 'Mixed text'] };
const t = (zh, en) => store.data.locale === 'en' ? en : zh;
const copyText = text => String(text || '').replace(/[。．]/g, '').replace(/\.(?=\s|$)/g, '');
const title = item => copyText(t(item.Title, item.TitleEn || item.Title));
const label = entry => t(entry[1], entry[2]);
const seconds = value => `${Math.floor(value / 60).toString().padStart(2, '0')}:${Math.floor(value % 60).toString().padStart(2, '0')}`;
let all = [], visible = [], page = 'daily', language = 'en', group = '', isLong = false, current = null, round = null;
let offline = 'loading', loading = true, editorID = '';
const paper = new Paper($('paper'), $('reference'), $('draft'), () => { if (!loading) { handleFinished(); renderStats(); } });

function selectOptions(element, choices, value) {
  element.replaceChildren(...choices.map(([key, zh, en]) => { const option = document.createElement('option'); option.value = key; option.textContent = t(zh, en); return option; }));
  if (choices.some(x => x[0] === value)) element.value = value;
  return element.value;
}
function populateFilters(reset = false) {
  const candidates = queryLessons(all, page, '', '', '', store.data.texts), keys = [...new Set(candidates.map(languageKey))];
  keys.sort((a, b) => (a === 'en' ? '0' : a === 'zh' ? '1' : '2' + a).localeCompare(b === 'en' ? '0' : b === 'zh' ? '1' : '2' + b));
  if (reset || !keys.includes(language)) language = keys[0] || '';
  language = selectOptions($('language-select'), keys.length ? keys.map(key => [key, ...(languages[key] || [key, key])]) : [['', '暂无语言', 'No languages']], language);
  let choices = topics;
  if (page === 'games') choices = [['', '全部挑战', 'All challenges'], ...games];
  if (page === 'exams') choices = [['', '全部题型', 'All task types'], ...['IELTS Task 1', 'IELTS Task 2', 'TOEFL Email', 'TOEFL Discussion', 'CET-4', 'CET-6'].map(x => [x, x, x])];
  if (reset) group = '';
  group = selectOptions($('group-select'), choices, group);
  $('group-field').hidden = page === 'code' || page === 'library';
  $('group-label').textContent = page === 'games' ? t('玩法', 'Challenge') : page === 'exams' ? t('题型', 'Task type') : t('分类', 'Topic');
  $('manage-texts').hidden = page !== 'library';
}
function renderLibrary(selectFirst = false) {
  visible = queryLessons(all, page, language, group, $('search').value, store.data.texts);
  const fragment = document.createDocumentFragment();
  for (const item of visible) {
    const button = document.createElement('button'); button.className = 'lesson'; button.dataset.id = item.Id;
    button.setAttribute('aria-current', String(current?.Id === item.Id));
    const name = document.createElement('strong'); name.textContent = title(item);
    const sub = document.createElement('small');
    const subject = page === 'games' ? label(games.find(x => x[0] === String(item.Game))) : item.IsCode ? item.Language : t(item.Category, item.CategoryEn);
    sub.textContent = `${subject || ''} · ${units(item.LongText).length} ${t('字', 'chars')}`;
    button.append(name, sub); button.addEventListener('click', () => { startRound(item); closeDrawer(false); paper.focus(); }); fragment.append(button);
  }
  if (!visible.length) { const empty = document.createElement('p'); empty.className = 'list-empty'; empty.textContent = page === 'library' ? t('先添加一篇自己的文本', 'Add your first text to begin') : t('没有匹配的文章', 'No matching texts'); fragment.append(empty); }
  $('lessons').replaceChildren(fragment); $('lesson-count').textContent = `${visible.length} ${t('篇', 'texts')}`;
  if (selectFirst) startRound(visible[0] || null);
}
function resultName(result) {
  return result === 'completed' ? t('练习完成', 'Practice complete') : result === 'timeUp' ? t('测试结束', 'Test finished') : result === 'lost' ? t('挑战结束', 'Challenge ended') : t('中途结束', 'Stopped early');
}
function saveRound(stopped = false) {
  if (persistRound(round, store, stopped)) renderStorageError();
}
function startRound(item) {
  saveRound(true); loading = true;
  const previous = current; current = item; round = null; paper.clear();
  if (!item) { loading = false; renderCurrent(); renderStats(); return; }
  const target = roundTarget(item, isLong, page, store.data.mistakes);
  const options = { game: item.Game, code: item.IsCode, timeLimit: page === 'test' ? Number($('duration').value) : 0, background: page === 'test' || item.Game === 4, mistakeLimit: item.Game === 2 ? 1 : item.Game === 5 ? isLong ? 5 : 3 : 0 };
  if (item.Game === 4) {
    if (previous?.Game !== 4 || languageKey(previous) !== languageKey(item)) $('pace').value = languageKey(item) === 'zh' ? '120' : '180';
    options.timeLimit = Math.max(1, Math.ceil(units(target.target).length * 60 / Number($('pace').value)));
  }
  round = { id: newID(), item, page, long: isLong, session: new Session(target.target, options), used: target.used, waiting: item.Game === 3, preview: false, peeking: false, memoryAt: 0, peeks: isLong ? 3 : 2, peeksUsed: 0, recordedMistakes: 0, savedSignature: '', cleared: false };
  paper.load(round.session); paper.setMask(round.waiting); paper.setAllowed(!round.waiting);
  loading = false; renderCurrent(); renderStats();
}
function renderCurrent() {
  $('lesson-title').textContent = current ? title(current) : t('选一篇文章开始', 'Choose a text to begin');
  $('lesson-description').textContent = current ? copyText(t(current.Description, current.DescriptionEn)) : t('可以选择内置文章，也可以添加自己的文本', 'Use the library or add your own text');
  $('empty-message').hidden = !!current; $('empty-message').textContent = t('从选文面板选择文章', 'Choose a text from the library');
  for (const id of ['short-button', 'long-button', 'next-button', 'shuffle-button', 'restart-button']) $(id).disabled = !current;
  $('short-button').setAttribute('aria-pressed', String(!isLong)); $('long-button').setAttribute('aria-pressed', String(isLong));
  $('duration').hidden = page !== 'test'; $('pace').hidden = current?.Game !== 4; $('race').hidden = current?.Game !== 4;
  $('peek-button').hidden = current?.Game !== 3; $('indent-button').hidden = !current?.IsCode;
  for (const button of $('lessons').querySelectorAll('.lesson')) button.setAttribute('aria-current', String(button.dataset.id === current?.Id));
  $('restart-button').textContent = round?.waiting ? t('开始记忆', 'Start recall') : t('重来', 'Restart');
  paper.setLabel(t('打字输入区', 'Typing area'));
}
function finalScore() { return round ? scoreRecord(round).score : 0; }
function handleFinished() {
  if (!round?.session.finished) return;
  paper.setMask(false); saveRound();
  if (current.Game === 5 && !round.cleared && round.session.reason === 'completed' && !round.session.errorCount && round.used.length) { store.clearMistakes(round.used); round.cleared = true; }
}
function renderStats() {
  const s = round?.session;
  $('speed').textContent = s?.hasStarted && s.elapsedSeconds >= 2 ? String(Math.round(s.cpm)) : '—';
  $('accuracy').textContent = s?.attempts ? `${s.accuracy.toFixed(1)}%` : '—';
  const timed = page === 'test' || current?.Game === 4;
  $('time-label').textContent = timed ? t('剩余', 'Time left') : t('用时', 'Time');
  $('time').textContent = seconds(s ? timed ? Math.ceil(Math.max(0, s.options.timeLimit - s.elapsedSeconds)) : s.elapsedSeconds : 0);
  $('progress-count').textContent = s ? `${s.position} / ${s.targetUnits.length}` : '0 / 0';
  $('paper-progress').style.width = `${s ? s.position * 100 / s.targetUnits.length : 0}%`;
  $('peek-button').textContent = `${t('偷看', 'Peek')} ${round?.peeks ?? 0}`;
  $('peek-button').disabled = !round || round.waiting || round.preview || round.peeking || s.finished || round.peeks <= 0;
  if (!s) { $('mode-note').textContent = ''; $('round-message').textContent = ''; return; }
  const game = current.Game;
  let note = copyText(t(current.SourceInfo, current.SourceInfoEn));
  if (page === 'test') note = t('第一次输入开始计时', 'The first key starts the clock');
  if (game === 1) note = `${t('连击', 'Combo')} ${s.combo}    ×${Math.min(5, 1 + Math.floor(s.combo / 10))}    ${t('得分', 'Score')} ${s.score}    ${t('90% 准确率过关', '90% accuracy to pass')}`;
  if (game === 2) note = t('打错一个字，本轮就结束', 'One wrong character ends the round');
  if (game === 3) note = round.waiting ? t('先看原文，再藏起默打', 'Preview the passage then type it from memory') : round.preview ? `${t('记住这一段', 'Remember this')}    ${Math.max(1, Math.ceil((isLong ? 8 : 4) - (Date.now() / 1000 - round.memoryAt)))} ${t('秒', 'sec')}` : round.peeking ? t('偷看中', 'Peeking') : `${t('原文已藏起', 'Text hidden')}    ${t('剩余偷看', 'Peeks left')} ${round.peeks}`;
  if (game === 4) {
    const ghost = Math.min(1, s.elapsedSeconds * Number($('pace').value) / 60 / s.targetUnits.length);
    $('your-race').style.width = `${s.correctCount * 100 / s.targetUnits.length}%`; $('ghost-race').style.width = `${ghost * 100}%`;
    const lead = s.correctCount - Math.floor(ghost * s.targetUnits.length); note = `${lead >= 0 ? t('领先', 'Ahead') : t('落后', 'Behind')} ${Math.abs(lead)} ${t('字', 'chars')}`;
  }
  if (game === 5) note = `${round.used.length ? t('自己的错词', 'Your mistake list') : t('易错词热身', 'Warm-up words')}    ${t('剩余机会', 'Lives left')} ${Math.max(0, s.options.mistakeLimit - s.totalMistakes)}`;
  $('mode-note').textContent = note;
  let message = !s.hasStarted ? t('点白色区域开始输入，使用系统键盘和输入法', 'Tap the white area to begin with your system keyboard') : !s.isRunning && !timed ? t('已暂停，点白色区域继续', 'Paused — tap the white area to continue') : current.IsCode ? t('Enter 换行，Tab 或「缩进」按钮缩进', 'Enter for a new line and Tab or the Tab button to indent') : t('Backspace 修改，练习区不接受粘贴', 'Backspace to edit — pasting is disabled in practice');
  if (game === 3 && round.waiting) message = t('点「开始记忆」看原文', 'Press Start recall to see the passage');
  else if (game === 3 && round.preview) message = t('记忆结束后，点白色区域打开键盘', 'When the preview ends tap the white area to open the keyboard');
  if (s.finished) message = `${resultName(s.reason)}   ${Math.round(s.cpm)} ${t('字/分', 'chars/min')}   ${s.accuracy.toFixed(1)}%   ${t('未改错误', 'Uncorrected')} ${s.errorCount}${game ? `   ${t('得分', 'Score')} ${finalScore()}` : ''}`;
  if ($('round-message').textContent !== message) $('round-message').textContent = message;
  $('round-message').classList.toggle('result', s.finished);
}
function renderStorageError() {
  const box = $('storage-error'); box.hidden = !store.error; box.replaceChildren();
  if (!store.error) return;
  box.append(document.createTextNode(store.error === 'read' ? t('无法读取本机记录，原记录已保留，可以恢复备份', 'Local records could not be read and the original has been retained') : t('本机记录暂时无法保存，当前更改仍在内存，建议导出备份', 'Changes could not be saved and remain in memory — export a backup')));
  const button = document.createElement('button'); button.textContent = t('导出备份', 'Export backup'); button.onclick = exportBackup; box.append(button);
}
function updateLocale() {
  document.documentElement.lang = store.data.locale === 'en' ? 'en' : 'zh-CN';
  for (const element of document.querySelectorAll('[data-zh][data-en]')) element.textContent = t(element.dataset.zh, element.dataset.en);
  $('locale-button').textContent = t('English', '中文');
  selectOptions($('workspace-select'), pages, page); $('workspace-caption').textContent = label(pages.find(x => x[0] === page));
  $('drawer-shade').setAttribute('aria-label', t('关闭选文', 'Close library')); $('library').setAttribute('aria-label', t('文章选择', 'Text library'));
  $('lessons').setAttribute('aria-label', t('文章列表', 'Text list')); $('paper').setAttribute('aria-label', t('打字练习区', 'Typing practice'));
  $('font-size').setAttribute('aria-label', t('字号', 'Text size')); $('duration').setAttribute('aria-label', t('测试时长', 'Test duration')); $('pace').setAttribute('aria-label', t('影子速度', 'Ghost speed'));
  document.querySelector('.length-switch').setAttribute('aria-label', t('文章长度', 'Text length'));
  [...$('duration').options].forEach(option => { const sec = Number(option.value); option.textContent = sec < 60 ? t('30 秒', '30 sec') : `${sec / 60} ${t('分钟', 'min')}`; });
  [...$('pace').options].forEach(option => option.textContent = `${option.value} ${t('字/分', 'chars/min')}`);
  populateFilters(); renderLibrary(); renderCurrent(); renderStats(); renderStorageError();
  $('offline-status').textContent = offline === 'ready' ? t('可离线使用', 'Ready offline') : offline === 'unsupported' ? t('当前浏览器仅支持在线使用', 'Online only in this browser') : offline === 'failed' ? t('离线内容未就绪，联网后重新打开', 'Offline setup incomplete — reopen when online') : t('正在准备离线内容', 'Preparing offline use');
}
function changePage(next) { page = next; $('search').value = ''; group = ''; populateFilters(true); renderLibrary(true); updateLocale(); }
function openDrawer() { document.querySelector('.app').classList.add('drawer-open'); $('drawer-shade').hidden = false; $('open-library').setAttribute('aria-expanded', 'true'); $('practice-main').inert = drawerLayout(); $('close-library').focus(); }
function closeDrawer(restore = true) { document.querySelector('.app').classList.remove('drawer-open'); $('drawer-shade').hidden = true; $('open-library').setAttribute('aria-expanded', 'false'); $('practice-main').inert = false; if (restore) $('open-library').focus(); }
function showDialog(id) { closeDrawer(false); $(id).showModal(); }
function beginMemory() { if (!round) return; round.waiting = false; round.preview = true; round.memoryAt = Date.now() / 1000; paper.setAllowed(false); paper.setMask(false); renderCurrent(); renderStats(); }
function restart() { if (round?.waiting) beginMemory(); else { startRound(current); paper.focus(); } }
function errorCopy(error) {
  const messages = { blank: ['请填写正文', 'Enter some text'], incomplete: ['请填写标题、语言和正文', 'Fill in title, language and text'], rtl: ['暂不支持从右向左排版的文章', 'Right-to-left passages are not supported'], tooLong: ['正文最多支持 40,000 个字符', 'Use no more than 40,000 characters'], tooLarge: ['文件过大，最多支持 4 MB', 'Use a file smaller than 4 MB'], control: ['文本含有无法输入的控制字符', 'The text contains an unsupported control character'], invalid: ['文本格式无效，请重新复制或选择文件', 'Invalid text or file — try copying it again'], textLimit: ['最多保存 200 篇个人文本', 'You can save up to 200 personal texts'] };
  const pair = messages[error.message] || messages.invalid; return t(...pair);
}
function fillEditor(item) { editorID = item?.id || ''; $('text-title').value = item?.title || ''; $('text-language').value = item?.language || ''; $('text-body').value = item?.text || ''; $('editor-error').textContent = ''; $('delete-text').disabled = !editorID; }
function manageTexts() {
  const options = [['', '新建文本', 'New text'], ...store.data.texts.map(x => [x.id, x.title, x.title])]; selectOptions($('saved-texts'), options, ''); fillEditor(null); showDialog('text-dialog');
}
function download(name, text) {
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json;charset=utf-8' }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = name; document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 10000);
}
function exportBackup() { saveRound(true); download('QuietType-backup.json', store.export()); }
function showHistory() {
  saveRound(true); const list = $('history-list'); list.replaceChildren();
  for (const record of store.data.results) {
    const item = document.createElement('div'); item.className = 'history-item'; const heading = document.createElement('strong'); heading.textContent = copyText(t(record.title, record.titleEn || record.title));
    const info = document.createElement('span'); const date = new Date(record.when); const dateText = Number.isNaN(date.valueOf()) ? '' : date.toLocaleString(store.data.locale === 'en' ? 'en-US' : 'zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    info.textContent = `${dateText} · ${record.language} · ${record.long ? t('长篇', 'Long') : t('短篇', 'Short')} · ${resultName(record.result)}\n${Math.round(record.cpm)} ${t('字/分', 'chars/min')} · ${record.accuracy.toFixed(1)}% · ${seconds(record.seconds)}`;
    item.append(heading, info); list.append(item);
  }
  if (!store.data.results.length) list.textContent = t('完成一次练习后，成绩会显示在这里', 'Your results will appear here after you practice');
  showDialog('history-dialog');
}
function viewport() {
  const view = window.visualViewport; const height = view && view.scale === 1 ? view.height : window.innerHeight;
  document.documentElement.style.setProperty('--app-height', `${height}px`);
  document.documentElement.classList.toggle('keyboard-open', height < 580);
  paper.positionInput();
  if (!drawerLayout() && document.querySelector('.app').classList.contains('drawer-open')) closeDrawer(false);
}
$('workspace-select').onchange = event => changePage(event.target.value);
$('language-select').onchange = event => { language = event.target.value; renderLibrary(true); };
$('group-select').onchange = event => { group = event.target.value; renderLibrary(true); };
$('search').oninput = () => renderLibrary();
$('short-button').onclick = () => { if (isLong) { isLong = false; startRound(current); paper.focus(); } };
$('long-button').onclick = () => { if (!isLong) { isLong = true; startRound(current); paper.focus(); } };
$('font-size').value = String(store.data.fontSize);
$('font-size').onchange = () => { store.data.fontSize = Number($('font-size').value); document.documentElement.style.setProperty('--text-size', `${store.data.fontSize}px`); paper.measure(); paper.positionInput(); store.save(); renderStorageError(); };
$('duration').onchange = () => startRound(current); $('pace').onchange = () => startRound(current);
$('next-button').onclick = () => { if (visible.length) { startRound(visible[(visible.findIndex(x => x.Id === current?.Id) + 1) % visible.length]); paper.focus(); } };
$('shuffle-button').onclick = () => { if (visible.length) { startRound(visible[Math.floor(Math.random() * visible.length)]); paper.focus(); } };
$('restart-button').onclick = restart;
$('peek-button').onclick = () => { if (!round || $('peek-button').disabled) return; round.peeks--; round.peeksUsed++; round.peeking = true; round.memoryAt = Date.now() / 1000; paper.setMask(false); paper.focus(); renderStats(); };
$('locale-button').onclick = () => { store.data.locale = store.data.locale === 'en' ? 'zh' : 'en'; store.save(); updateLocale(); };
$('open-library').onclick = openDrawer; $('close-library').onclick = () => closeDrawer(); $('drawer-shade').onclick = () => closeDrawer();
$('history-button').onclick = showHistory; $('help-button').onclick = () => showDialog('help-dialog'); $('manage-texts').onclick = manageTexts;
for (const button of document.querySelectorAll('.close-dialog')) button.onclick = () => button.closest('dialog').close();
$('saved-texts').onchange = () => fillEditor(store.data.texts.find(x => x.id === $('saved-texts').value));
$('new-text').onclick = () => { $('saved-texts').value = ''; fillEditor(null); $('text-title').focus(); };
$('text-form').onsubmit = event => {
  event.preventDefault();
  try { const item = { id: editorID || newID(), title: $('text-title').value, language: $('text-language').value, text: $('text-body').value }; store.saveText(item); $('text-dialog').close(); page = 'library'; language = languageKey({ Language: item.language }); $('search').value = ''; populateFilters(); renderLibrary(); startRound(visible.find(x => x.Id === `user:${item.id}`) || visible[0]); updateLocale(); paper.focus(); }
  catch (error) { $('editor-error').textContent = errorCopy(error); }
};
$('delete-text').onclick = () => {
  if (!editorID || !confirm(t('删除这篇个人文本', 'Delete this saved text'))) return;
  store.deleteText(editorID); manageTexts(); populateFilters(); renderLibrary(true); renderStorageError();
};
$('import-text').onclick = () => $('txt-file').click();
$('txt-file').onchange = async event => {
  const file = event.target.files[0]; if (!file) return;
  try { if (file.size > 4 * 1024 * 1024) throw new Error('tooLarge'); const text = await file.text(); $('text-body').value = text; if (!$('text-title').value) $('text-title').value = file.name.replace(/\.txt$/i, ''); $('editor-error').textContent = ''; }
  catch (error) { $('editor-error').textContent = errorCopy(error); } finally { event.target.value = ''; }
};
$('export-backup').onclick = exportBackup; $('import-backup').onclick = () => $('backup-file').click();
$('backup-file').onchange = async event => {
  const file = event.target.files[0]; if (!file) return;
  try { if (file.size > 4 * 1024 * 1024) throw new Error('tooLarge'); const text = await file.text(); JSON.parse(text); if (!confirm(t('用这份备份替换本机文本和成绩，建议先导出当前备份', 'Replace local texts and results with this backup — export your current backup first'))) return; store.import(text); round = null; current = null; paper.clear(); $('history-dialog').close(); changePage('daily'); updateLocale(); }
  catch (error) { alert(errorCopy(error)); } finally { event.target.value = ''; }
};
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && document.querySelector('.app').classList.contains('drawer-open')) closeDrawer();
  if (document.activeElement === paper.input && !paper.buffer.composing && (event.metaKey || event.ctrlKey)) {
    if (event.key.toLowerCase() === 'r') { event.preventDefault(); restart(); }
    if (event.key.toLowerCase() === 'n') { event.preventDefault(); $('next-button').click(); }
  }
});
document.addEventListener('visibilitychange', () => { paper.visibility(); if (document.hidden) saveRound(true); renderStats(); });
window.addEventListener('pagehide', () => saveRound(true));
window.visualViewport?.addEventListener('resize', viewport); window.visualViewport?.addEventListener('scroll', () => paper.positionInput()); window.addEventListener('resize', viewport);
setInterval(() => {
  if (!round) return;
  const elapsed = Date.now() / 1000 - round.memoryAt;
  if (round.preview && elapsed >= (isLong ? 8 : 4)) { round.preview = false; paper.setMask(true); paper.setAllowed(true); }
  if (round.peeking && elapsed >= 1.8) { round.peeking = false; paper.setMask(true); }
  round.session.tick(); handleFinished(); renderStats();
}, 250);
async function start() {
  viewport(); document.documentElement.style.setProperty('--text-size', `${store.data.fontSize}px`);
  try {
    const response = await fetch('./lessons.json'); if (!response.ok) throw new Error('catalogue'); all = await response.json();
    if (!Array.isArray(all) || !all.length || !all.every(x => x.Id && x.ShortText && x.LongText)) throw new Error('catalogue');
    loading = false; populateFilters(); renderLibrary(true); updateLocale();
  } catch { loading = false; $('lesson-title').textContent = t('练习内容暂时无法读取', 'Practice texts could not be loaded'); $('lesson-description').textContent = t('请联网后重新打开页面', 'Reconnect and reopen this page'); }
  if (!('serviceWorker' in navigator)) offline = 'unsupported';
  else try { const registration = await navigator.serviceWorker.register('./sw.js', { scope: './' }); await offlineReady(registration); offline = 'ready'; }
  catch { offline = 'failed'; }
  $('offline-status').textContent = offline === 'ready' ? t('可离线使用', 'Ready offline') : offline === 'unsupported' ? t('当前浏览器仅支持在线使用', 'Online only in this browser') : t('离线内容未就绪，联网后重新打开', 'Offline setup incomplete — reopen when online');
}
const indent = document.createElement('button'); indent.id = 'indent-button'; indent.dataset.zh = '缩进'; indent.dataset.en = 'Tab'; indent.textContent = '缩进'; indent.hidden = true; indent.onclick = () => paper.indent(); $('peek-button').before(indent);
start();
